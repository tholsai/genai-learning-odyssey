"""Core modules for the application."""

